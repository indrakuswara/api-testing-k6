# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: get.spec.ts >> TC-API-005 [@smoke] GET /objects/7 returns the object with id "7"
- Location: api-tests/tests/get.spec.ts:47:5

# Error details

```
Error: apiRequestContext.get: aborted
Call log:
  - → GET https://api.restful-api.dev/objects/7
    - user-agent: Playwright/1.63.0 (x64; ubuntu 24.04) node/24.20
    - accept: application/json
    - accept-encoding: gzip,deflate,br
    - Content-Type: application/json
  - ← 200 OK
    - date: Tue, 29 Sep 2026 11:17:29 GMT
    - content-type: application/json;charset=UTF-8
    - transfer-encoding: chunked
    - connection: close
    - server: cloudflare
    - nel: {"report_to":"cf-nel","success_fraction":0.0,"max_age":604800}
    - vary: Origin, Access-Control-Request-Method, Access-Control-Request-Headers
    - x-content-type-options: nosniff
    - x-xss-protection: 1; mode=block
    - cache-control: no-cache, no-store, max-age=0, must-revalidate
    - pragma: no-cache
    - expires: 0
    - x-frame-options: DENY
    - cf-cache-status: DYNAMIC
    - report-to: {"group":"cf-nel","max_age":604800,"endpoints":[{"url":"https://a.nel.cloudflare.com/report/v4?s=8p1dnyujEdxIxnrb5t5Wk9aflQoFv228GZ5ifG4FxU0EqXyNPIcH%2Bo4Vyw8MDES8RE1S04fOh3hXBB%2FbvW9Rg47WHGhW5JZY9PhSLAwxeiQ0JYIBo9OWke0x4xs1k2WWd0ZMbW6oe21UPd6aSk0%2B1y3D"}]}
    - content-encoding: br
    - cf-ray: a42a94ec8e6b5193-ATL
    - alt-svc: h3=":443"; ma=86400

```

# Test source

```ts
  1  | import { test, expect, type APIRequestContext } from '@playwright/test';
  2  | import { newApiContext, endpoints } from '../utils/api-client';
  3  | import { apiObjectListSchema, apiObjectSchema } from '../utils/schemas';
  4  | 
  5  | let ctx: APIRequestContext;
  6  | 
  7  | test.beforeAll(async () => {
  8  |   ctx = await newApiContext();
  9  | });
  10 | 
  11 | test.afterAll(async () => {
  12 |   await ctx.dispose();
  13 | });
  14 | 
  15 | test('TC-API-001 [@smoke] GET /objects returns 200 with a JSON array', async () => {
  16 |   const res = await ctx.get(endpoints.objects);
  17 |   expect(res.status()).toBe(200);
  18 |   expect(res.headers()['content-type']).toContain('application/json');
  19 |   const body = await res.json();
  20 |   expect(Array.isArray(body)).toBe(true);
  21 |   expect(body.length).toBeGreaterThan(0);
  22 | });
  23 | 
  24 | test('TC-API-002 [@regression] every item matches the object schema', async () => {
  25 |   const res = await ctx.get(endpoints.objects);
  26 |   expect(res.status()).toBe(200);
  27 |   const parsed = apiObjectListSchema.safeParse(await res.json());
  28 |   expect(parsed.success, JSON.stringify(parsed).slice(0, 500)).toBe(true);
  29 | });
  30 | 
  31 | test('TC-API-003 [@regression] GET /objects responds within 2 seconds', async () => {
  32 |   const started = Date.now();
  33 |   const res = await ctx.get(endpoints.objects);
  34 |   const elapsed = Date.now() - started;
  35 |   expect(res.status()).toBe(200);
  36 |   expect(elapsed).toBeLessThan(2000);
  37 | });
  38 | 
  39 | test('TC-API-004 [@regression] GET /objects?id=3&id=5 returns only requested ids', async () => {
  40 |   const res = await ctx.get(endpoints.objectByIds([3, 5]));
  41 |   expect(res.status()).toBe(200);
  42 |   const body = await res.json();
  43 |   const ids = (body as Array<{ id: string }>).map((o) => o.id).sort();
  44 |   expect(ids).toEqual(['3', '5']);
  45 | });
  46 | 
  47 | test('TC-API-005 [@smoke] GET /objects/7 returns the object with id "7"', async () => {
> 48 |   const res = await ctx.get(endpoints.objectById(7));
     |                         ^ Error: apiRequestContext.get: aborted
  49 |   expect(res.status()).toBe(200);
  50 |   const body = await res.json();
  51 |   expect(body.id).toBe('7');
  52 |   const parsed = apiObjectSchema.safeParse(body);
  53 |   expect(parsed.success).toBe(true);
  54 | });
  55 | 
  56 | test('TC-API-006 [@regression] GET non-existent id returns 404', async () => {
  57 |   const res = await ctx.get(endpoints.objectById(99999999));
  58 |   expect(res.status()).toBe(404);
  59 |   expect(await res.text()).toContain('not found');
  60 | });
  61 | 
  62 | test('TC-API-007 [@regression] GET non-numeric id returns 404', async () => {
  63 |   const res = await ctx.get(endpoints.objectById('abc'));
  64 |   expect(res.status()).toBe(404);
  65 | });
  66 | 
```